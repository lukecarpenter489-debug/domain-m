
exports.handler = async (event) => {
  const params = event.queryStringParameters || {};
  const domain = params.domain;
  if (!domain) return { statusCode: 400, body: "Missing domain" };
  if (!process.env.UD_MCP_API_KEY) return { statusCode: 500, body: "Missing Netlify environment variable UD_MCP_API_KEY" };

  const res = await fetch(`https://resolve.unstoppabledomains.com/domains/${encodeURIComponent(domain)}`, {
    headers: { Authorization: `Bearer ${process.env.UD_MCP_API_KEY}` }
  });

  const data = await res.text();
  return {
    statusCode: res.status,
    headers: {
      "Content-Type": "application/json",
      "Access-Control-Allow-Origin": "*"
    },
    body: data
  };
};
